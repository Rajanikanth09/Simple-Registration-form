var mongoose=require('mongoose');
var xyz=new mongoose.Schema({
name:String,
about:String,
langdrp:String,
gender:String,
hobbies:String,
img:String
})
var zyx=mongoose.model('user',xyz);
module.exports=zyx;