var express = require('express');
var router = express.Router();
var user=require('../modules/user');
var fs=require("fs");

/* GET home page. */

router.get('/', function(req, res, next) {
  res.render('views/index');
});

router.post('/savef', function(req, res) {
	var imgs=req.body;
	if(imgs.img!=null && imgs.img.filename!=undefined){
		
		var filename=imgs.img.filename;
		if(imgs.img.filetype=="image/jpeg"){filename='/upload/'+filename};
		if(imgs.img.filetype=="image/jpg"){filename='/upload/'+filename};
		if(imgs.img.filetype=="image/png"){filename='/upload/'+filename};
		
		
		fs.writeFile('public'+filename,new Buffer(imgs.img.base64,'base64'),function(err){
			if(err){
				console.log(err);
			}else{
				console.log("img upladed");
				req.body.img=filename;
			}
		
  var insertdata = new user(req.body);
  insertdata.save(function(err,data){
	 if(err){
		 console.log("err"+err);
	 } else{
		 console.log(data);
		 res.send(data);
	 }
	  
  });
});
	}
});
	
router.post('/view', function(req, res) {

  user.find({},function(err,data){
	 if(err){
		 console.log("err"+err);
	 } else{
		 console.log(data);
		 res.send(data);
	 }
	  
  })
});
router.post('/dlt', function(req, res) {

  user.find({_id:req.body.id}).remove(function(err,data){
	 if(err){
		 console.log("err"+err);
	 } else{
		 console.log(data);
		 res.send(data);
	 }
	  
  })
});
router.post('/edt', function(req, res) {

  user.find({_id:req.body.id},function(err,data){
	 if(err){
		 console.log("err"+err);
	 } else{
		 console.log(data);
		 res.send(data);
	 }
	  
  })
});
router.post('/updt', function(req, res) {
	
	var imgup=req.body.frm;
	if(imgup.img!=null && imgup.img.filename!=undefined){
		
		var filename=imgup.img.filename;
		if(imgup.img.filetype=="image/jpeg"){filename='/upload/'+filename};
		if(imgup.img.filetype=="image/jpg"){filename='/upload/'+filename};
		if(imgup.img.filetype=="image/png"){filename='/upload/'+filename};
		
		
		fs.writeFile('public'+filename,new Buffer(imgup.img.base64,'base64'),function(err){
			if(err){
				console.log(err);
			}else{
				console.log("img upladed");
				req.body.frm.img=filename;
			
var cd=req.body.frm;
  user.findOneAndUpdate({_id:req.body.objid},{$set:{name:cd.name,about:cd.about,lang:cd.lang,gender:cd.gender,hobbies:cd.hobbies,langdrp:cd.langdrp,img:cd.img}},function(err,data){
	 if(err){
		 console.log("err"+err);
	 } else{
		 console.log(data);
		 res.send(data);
	 }
	  
  });
		}
});
}
});
module.exports = router;
