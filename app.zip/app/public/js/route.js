var drop="";
var arr=[];

var app=angular.module("raj",['ngRoute','naif.base64']);
app.controller("rfrm",function($scope,$http,$routeParams){
	
	$scope.drp=function(){
		var drpd=document.getElementById("langdrp").value;
		if(arr.indexOf(drpd)==-1){
			arr.push(drpd);
		drop +='<div id="'+drpd+'"><label>'+drpd+'</label><input type="button" value="X" onclick="remv('+"'"+drpd+"'"+')"><br></div>';
		
		document.getElementById("elan").innerHTML+=drop;	
		}else{
			alert("already exist");
			
		}
drop="";		
	}
	
	
	//============edit=============
	var objid=$routeParams.sri;
	
	$http.post('/index/edt',{id:objid}).then(function(res,status){
		var drpp="";
		$scope.f=res.data[0];
		
		var hobbiesedit=res.data[0].hobbies;
			hobbiesedit = hobbiesedit.split(',');
			
		var hobbiesstore=document.getElementsByName("hobbies"); 
			for(i=0;i<hobbiesedit.length;i++){
				for(j=0;j<hobbiesstore.length;j++){
					if(hobbiesedit[i]==hobbiesstore[j].value){
						hobbiesstore[j].checked=true;
					}
				}
			}
			
		var drpedt=res.data[0].langdrp;
		arr=drpedt.split(",");
		for(i=0;i<arr.length;i++){
		
		drpp +='<div id="'+arr[i]+'"><label>'+arr[i]+'</label><input type="button" value="X" onclick="remv('+"'"+arr[i]+"'"+')"><br></div>';
	}
		document.getElementById("elan").innerHTML=drpp;
	});
	
	$scope.rsubmit=function(frm){
			
	var hob=document.getElementsByName("hobbies");
	var v=[];
	var checkcount = 0;
	for(var i=0;i<hob.length;i++){
		if(hob[i].checked == true){
			checkcount++;
			v.push(hob[i].value);
			
		}
	}
	if(checkcount == 0){
		document.getElementById("hobEmpty").innerHTML='select hobbies';
		//return false;
	}else{
		document.getElementById("hobEmpty").innerHTML='';
	}
		
		frm.hobbies=v.toString();
		
	frm.langdrp=arr.toString();
		
		
		
		if(objid==undefined){
		
		$http.post('/index/savef',frm,function(req,res){
			
			console.log("ok");
		});
		}
		else{
			
			$http.post('/index/updt',{objid:objid,frm:frm},function(req,res){
				
			});
		}
	}
});

function remv(rem){
	var r="";
	var remd=arr.indexOf(rem);
	arr.splice(remd,1);
	for(i=0;i<arr.length;i++){
		
		r +='<div id="'+arr[i]+'"><label>'+arr[i]+'</label><input type="button" value="X" onclick="remv('+"'"+arr[i]+"'"+')"><br></div>';
	}
	document.getElementById("elan").innerHTML=r;
}

app.controller("display",function($scope,$http){
	var y={f:1};
	$http.post('/index/view',y).then(function(res,status){
		
		console.log("display");
		
		$scope.f=res.data;
	});
	
	$scope.delet=function(object){
		var obj={id:object};
		$http.post('/index/dlt',obj,function(req,res){
			
			console.log("deleted");
			
		})
	}
	
	
});



app.config(function($routeProvider){
	$routeProvider
	.when('/form',{
		templateUrl:'views/frontend/form.html'
		
	})
	.when('/form/:sri',{
		templateUrl:'views/frontend/form.html'
		
	})
	
	.when('/show',{
		templateUrl:'views/admin/show.html'
		
	})
	.when('/home',{
		templateUrl:'views/frontend/home.html'
		
	})
	.when('/about',{
		templateUrl:'views/frontend/about.html'
		
	})
	
});